import java.util.ArrayList;
public class Main {
/*
Sample Implementatino for the ReadIn class
 */
//    public static void main(String[] args) {
//        ReadIn r = new ReadIn();
//        ArrayList<Inventory> test = r.ScanIn();
//        test.toString();
//    }
}
