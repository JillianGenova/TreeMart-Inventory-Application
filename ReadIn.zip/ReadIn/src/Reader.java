import java.util.ArrayList;

public interface Reader {
    public ArrayList<Product> ScanIn();
}
