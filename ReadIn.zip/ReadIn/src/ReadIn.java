import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.util.ArrayList;
// @author Yash Butani
public class ReadIn {

    public static ArrayList<Inventory> items = new ArrayList<>();

    public ReadIn() {
        // constructor does nothing right now
        /*
        when creating an object of type ReadIn just make a new object
        then make an arraylist and set that equal to ScanIn() so that the method populates the
        arraylist with values
         */


    }

    public  ArrayList<Inventory> ScanIn() {
        try {
            File input = new File("listdata.csv");
            Scanner in = new Scanner(input);
            String line = "";
            while (in.hasNextLine() && line != null) {
                line = in.nextLine();
                String[] parse = line.split(",");
                items.add(new Inventory(Double.parseDouble(parse[0]), parse[1], Double.parseDouble(parse[2]), Double.parseDouble(parse[3]), Double.parseDouble(parse[4]), Double.parseDouble(parse[5])));
                return items;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
       return items;
    }




}
